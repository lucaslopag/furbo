#!/bin/bash
# Lanzador de Furbo para Linux
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$DIR"

# 1. Auto-actualizar si hay git
if command -v git &>/dev/null && [ -d .git ]; then
    git pull --quiet 2>/dev/null
fi

# 2. Comprobar e iniciar motor AceStream en Linux si no responde
if ! curl -s http://127.0.0.1:6878/webui/api/service?method=get_version >/dev/null 2>&1; then
    echo "[*] AceStream no está respondiendo. Iniciando motor..."
    if command -v docker >/dev/null 2>&1; then
        sudo docker start tor-proxy 2>/dev/null || true
        sudo docker start acestream 2>/dev/null || true
    fi
    # Buscar binarios nativos alternativos
    if command -v acestreamengine >/dev/null 2>&1; then
        acestreamengine --client-console >/dev/null 2>&1 &
    elif [ -f "$HOME/.ACEStream/engine/app.py" ]; then
        python3 "$HOME/.ACEStream/engine/app.py" >/dev/null 2>&1 &
    fi
fi

# 3. Instalar dependencias si falta algo
python3 -c "import odf" 2>/dev/null || pip install -r backend/requirements.txt --quiet 2>/dev/null || pip3 install -r backend/requirements.txt --quiet 2>/dev/null

# 4. Limpieza al salir. La VPN (WARP) la gestiona el propio launcher de Python:
#    la conecta sola, la vigila y la apaga al cerrar.
trap 'sudo docker stop tor-proxy >/dev/null 2>&1 || true' EXIT INT TERM

# 5. Ejecutar launcher
python3 backend/acestream_launcher.py "$@"
